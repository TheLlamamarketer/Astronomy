#ASTRO 2

import numpy as np
from Winkelumrechner import *

c=np.pi/180

satalpha2025=hour_to_dez((23,46,55.89))*c
satdelta2025=degree_to_dez((-4,3,56.62))*c

arcalpha2000=hour_to_dez((14,15,39.6721))*c
arcdelta2000=degree_to_dez((19,10,56.673))*c

arcT=25.8671239

p=360/25772

e=dez_to_rad(23.45)

#PRÄZESSION

def precession(alpha, delta, T):
    delalpha=T*p*(np.cos(e)+np.sin(e)*np.sin(alpha)*np.tan(delta))

    deldelta=T*p*np.cos(alpha)*np.sin(e)

    return delalpha, deldelta

#SATURN keine Präzessionskorrektur, weil zu schnell

#ARCTURUS
arcalpha_p=arcalpha2000 + precession(arcalpha2000, arcdelta2000, arcT)[0]
arcdelta_p=arcdelta2000 + + precession(arcalpha2000, arcdelta2000, arcT)[1]


#ORTSZEITEN
b=degree_to_rad((52,27,13.9))
l=degree_to_rad((13,17,48.8))
time=17*15*c

theta0=hour_to_rad((3,25,30.8376))

thetaG=theta0 + time * 366.24/365.24
thetaFU=thetaG + l

#STUNDENWINKEL

arctau=thetaG-arcalpha_p
sattau=thetaG-satalpha2025

#HÖHE UND AZIMUTH

def h_and_A(delta, tau):

    z=np.arccos(
        np.cos(b)*np.cos(delta)*np.cos(tau) + np.sin(b)*np.sin(delta)
    )

    h=90-rad_to_dez(z)

    A_1=np.arcsin(
        -np.cos(delta)*np.sin(tau)/np.sin(z)
    )

    A_2=np.arccos(
    (-np.sin(b)*np.cos(delta)*np.cos(tau) + np.cos(b)*np.sin(delta))/np.sin(z)
    )

    return h, A_1, A_2

#KULMINATIONEN

    #benutzt arcdelta_p, arcalpha_p, satdelta2025, satalpha2025

def h_and_t(alpha, delta, tau, theta0):
    h_beob=h_and_A(delta, tau)[0]

    t_beob=365.24/366.24*(tau - theta0 - l + alpha)

    return h_beob, t_beob

#AUF- UND UNTERGANG

#h=0 

def up_and_down(delta, alpha):
    tau_1=np.arccos(
        -np.tan(b)*np.tan(delta)
    )

    tau_2=2*np.pi-tau_1

    t_updown=365.24/366.24*(tau_1 - theta0 - l + alpha)
    t_downup=365.24/366.24*(tau_2 - theta0 - l + alpha)

    return t_downup, t_downup

objects=["Arcturus","Saturn"]

for alpha, delta in [[arcalpha2000, arcdelta2000],[satalpha2025, satdelta2025]]:
    print(f"Präzessionskorrektur Arcturus: α={int(rad_to_hour(alpha)[0])} h {int(rad_to_hour(alpha)[1])} m {rad_to_hour(alpha)[2]:.4f} s, δ={int(rad_to_degree(delta)[0])}° {int(rad_to_degree(delta)[1])}' {rad_to_degree(delta)[2]:.4f}")

    





